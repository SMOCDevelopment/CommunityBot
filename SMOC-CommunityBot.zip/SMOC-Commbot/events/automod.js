const { Events, EmbedBuilder } = require('discord.js');
const config = require('../config');

const WHITELISTED_ROLES = [
  config.roles.manager,
  config.roles.admin,
  config.roles.linkBypass
];

const BANNED_WORDS = ['nigger', 'faggot', 'cracker', 'gay'];
const LINK_REGEX = /https?:\/\/[^\s]+/gi;
const TIMEOUT_DURATION_MS = 5 * 60 * 1000; // 5 Minutes

const GUILD_ID = config.guildId;
const LOG_CHANNEL_ID = config.logs.mod_log;

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (
      message.author.bot ||
      !message.guild ||
      message.guild.id !== GUILD_ID ||
      !message.member
    ) return;

    if (message.member.roles.cache.some(role => WHITELISTED_ROLES.includes(role.id))) return;

    const content = message.content.toLowerCase();
    const hasBannedWord = BANNED_WORDS.some(word => content.includes(word));
    const hasLink = LINK_REGEX.test(content);

    if (!hasBannedWord && !hasLink) return;

    const reason = hasBannedWord ? 'Inappropriate language' : 'Posting a link';

    try {
      await message.delete();
      await message.member.timeout(TIMEOUT_DURATION_MS, reason);

      const dmEmbed = new EmbedBuilder()
        .setTitle('Automod Action Taken')
        .setDescription(`Your message in **${message.guild.name}** was removed because it contained ${
          hasBannedWord ? 'a banned word' : 'a link'
        } (${reason}). You have been timed out for 5 minutes.`)
        .setColor('Orange')
        .setFooter({ text: 'Please review the server rules to avoid further actions.' })
        .setTimestamp();

      try {
        await message.author.send({ embeds: [dmEmbed] });
      } catch {
        console.warn(`Could not DM ${message.author.tag}.`);
      }

      const logChannel = await message.client.channels.fetch(LOG_CHANNEL_ID);
      if (logChannel?.isTextBased()) {
        const logEmbed = new EmbedBuilder()
          .setTitle('Automod Triggered')
          .setColor('Red')
          .addFields(
            { name: 'User', value: `<@${message.author.id}> (${message.author.tag})`, inline: false },
            { name: 'Channel', value: `<#${message.channel.id}>`, inline: true },
            { name: 'Reason', value: reason, inline: true },
            { name: 'Message', value: message.content.slice(0, 1024) || 'N/A', inline: false }
          )
          .setTimestamp();

        await logChannel.send({ embeds: [logEmbed] });
      }
    } catch (error) {
      console.error('Error in automod handler:', error);
    }
  },
};

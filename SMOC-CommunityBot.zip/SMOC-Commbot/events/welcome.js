const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');

const WELCOME_CHANNEL_ID = config.channels.welcome_channel;
const WELCOME_ROLE_ID = config.roles.member;

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const welcomeChannel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
    if (!welcomeChannel) return;

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('Welcome to the Server!')
      .setDescription(`Hello <@${member.id}>, welcome to our server!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: `Member #${member.guild.memberCount}` })
      .setTimestamp();

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('sent_from')
        .setLabel(`Sent From: ${member.guild.name}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),

      new ButtonBuilder()
        .setLabel('Bot Designed By: SMOC')
        .setURL('https://discord.gg/6r3j3dydUr')
        .setStyle(ButtonStyle.Link)
    );

    try {
      if (!member.roles.cache.has(WELCOME_ROLE_ID)) {
        await member.roles.add(WELCOME_ROLE_ID);
      }

      await welcomeChannel.send({ embeds: [embed] });

      await member.send({ embeds: [embed], components: [buttons] });

      console.log(`Sent welcome message and assigned role to ${member.user.tag}, DM sent successfully.`);
    } catch (error) {
      console.error('Error adding role or sending welcome message/DM:', error);

      try {
        await welcomeChannel.send({
          content: `Welcome <@${member.id}>! However, I couldn't assign you the member role or send you a DM. Please contact an admin.`,
        });
      } catch (sendError) {
        console.error('Failed to send error message in welcome channel:', sendError);
      }
    }
  },
};

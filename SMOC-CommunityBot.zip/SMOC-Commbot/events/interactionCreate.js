const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) {
        return interaction.reply({ content: 'Command not found.', ephemeral: true });
      }

      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error(`Error in command ${interaction.commandName}:`, error);
        if (!interaction.replied) {
          interaction.reply({ content: 'There was an error executing this command.', ephemeral: true });
        }
      }
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'role_selector') {
        const selectedRoleId = interaction.values[0];
        const role = interaction.guild.roles.cache.get(selectedRoleId);

        if (!role) {
          return interaction.reply({ content: '❌ Role not found.', ephemeral: true });
        }

        try {
          const member = interaction.member;
          let replyMsg = '';

          if (member.roles.cache.has(role.id)) {
            await member.roles.remove(role);
            replyMsg = `🗑️ Removed **${role.name}** role.`;
          } else {
            await member.roles.add(role);
            replyMsg = `✅ Assigned **${role.name}** role.`;
          }

          const originalMenu = interaction.component;

          const refreshedMenu = new StringSelectMenuBuilder()
            .setCustomId('role_selector')
            .setPlaceholder(originalMenu.placeholder || 'Choose a role...')
            .setMinValues(originalMenu.minValues ?? 1)
            .setMaxValues(originalMenu.maxValues ?? 1)
            .addOptions(originalMenu.options);

          const newRow = new ActionRowBuilder().addComponents(refreshedMenu);

          await interaction.update({
            components: [newRow],
            embeds: interaction.message.embeds,
            content: interaction.message.content,
          });

          await interaction.followUp({
            content: replyMsg,
            ephemeral: true,
          });

        } catch (err) {
          console.error('Role toggle error:', err);
          return interaction.reply({
            content: '❌ Could not update your role.',
            ephemeral: true
          });
        }
      }
    }
  }
};

const { Events, AuditLogEvent, EmbedBuilder } = require('discord.js');
const config = require('../config.js');
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`Guild activity logger initialized as ${client.user.tag}`);

    async function fetchActor(guild, type, targetId) {
      const auditLogs = await guild.fetchAuditLogs({ type, limit: 5 });
      return auditLogs.entries.find(entry => entry.target.id === targetId)?.executor;
    }

    // Role added/removed
    client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
      const logChannel = await client.channels.fetch(MOD_LOG_CHANNEL_ID);
      const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
      const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

      for (const role of addedRoles.values()) {
        const executor = await fetchActor(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
        const embed = new EmbedBuilder()
          .setTitle('Role Assigned')
          .setDescription(`${newMember} was **given** the role **${role.name}**`)
          .addFields({ name: 'Executor', value: executor?.tag || 'Unknown' })
          .setColor('Green')
          .setTimestamp();
        logChannel.send({ embeds: [embed] });
      }

      for (const role of removedRoles.values()) {
        const executor = await fetchActor(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
        const embed = new EmbedBuilder()
          .setTitle('Role Removed')
          .setDescription(`${newMember} **lost** the role **${role.name}**`)
          .addFields({ name: 'Executor', value: executor?.tag || 'Unknown' })
          .setColor('Red')
          .setTimestamp();
        logChannel.send({ embeds: [embed] });
      }
    });

    // Channel created/deleted
    client.on(Events.ChannelCreate, async channel => {
      const executor = await fetchActor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
      const embed = new EmbedBuilder()
        .setTitle('Channel Created')
        .setDescription(`Channel: <#${channel.id}> (${channel.name})`)
        .addFields({ name: 'Created By', value: executor?.tag || 'Unknown' })
        .setColor('Green')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    client.on(Events.ChannelDelete, async channel => {
      const executor = await fetchActor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
      const embed = new EmbedBuilder()
        .setTitle('Channel Deleted')
        .setDescription(`Channel: **${channel.name}** (ID: ${channel.id})`)
        .addFields({ name: 'Deleted By', value: executor?.tag || 'Unknown' })
        .setColor('Red')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    // Role created/deleted
    client.on(Events.GuildRoleCreate, async role => {
      const executor = await fetchActor(role.guild, AuditLogEvent.RoleCreate, role.id);
      const embed = new EmbedBuilder()
        .setTitle('Role Created')
        .setDescription(`RoleID: ${role.id} `)
        .addFields({ name: 'Created By', value: executor?.tag || 'Unknown' })
        .setColor('Green')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    client.on(Events.GuildRoleDelete, async role => {
      const executor = await fetchActor(role.guild, AuditLogEvent.RoleDelete, role.id);
      const embed = new EmbedBuilder()
        .setTitle('Role Deleted')
        .setDescription(`Role: **${role.name}** (ID: ${role.id})`)
        .addFields({ name: 'Deleted By', value: executor?.tag || 'Unknown' })
        .setColor('Red')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    // Webhook created/deleted
    client.on(Events.WebhooksUpdate, async channel => {
      const logs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.WebhookCreate });
      const entry = logs.entries.first();
      if (!entry) return;

      const embed = new EmbedBuilder()
        .setTitle('Webhook Created')
        .setDescription(`Webhook updated in <#${channel.id}>`)
        .addFields({ name: 'By', value: entry.executor.tag })
        .setColor('Orange')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    // Message deleted
    client.on(Events.MessageDelete, async message => {
      if (message.partial || !message.guild) return;

      const embed = new EmbedBuilder()
        .setTitle('Message Deleted')
        .addFields(
          { name: 'User', value: `${message.author.tag} (${message.author.id})` },
          { name: 'Channel', value: `<#${message.channel.id}>` },
          { name: 'Content', value: message.content || '*No content*' }
        )
        .setColor('Red')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    // Voice state
    client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
      const member = newState.member;
      const logChannel = client.channels.cache.get(MOD_LOG_CHANNEL_ID);

      if (!oldState.channel && newState.channel) {
        const embed = new EmbedBuilder()
          .setTitle('Voice Channel Join')
          .setDescription(`${member} joined **${newState.channel.name}**`)
          .setColor('Blue')
          .setTimestamp();
        logChannel.send({ embeds: [embed] });
      } else if (oldState.channel && !newState.channel) {
        const embed = new EmbedBuilder()
          .setTitle('Voice Channel Leave')
          .setDescription(`${member} left **${oldState.channel.name}**`)
          .setColor('Grey')
          .setTimestamp();
        logChannel.send({ embeds: [embed] });
      }
    });

    // Member left
    client.on(Events.GuildMemberRemove, async member => {
      const embed = new EmbedBuilder()
        .setTitle('Member Left')
        .setDescription(`${member.user.tag} has left the server.`)
        .setColor('Red')
        .setTimestamp();
      client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
    });

    // Suspicious account joined
    client.on(Events.GuildMemberAdd, async member => {
      const accountAge = Date.now() - member.user.createdTimestamp;
      const isSuspicious = accountAge < 1000 * 60 * 60 * 24 * 14 || !member.user.verified;

      if (isSuspicious) {
        const embed = new EmbedBuilder()
          .setTitle('Suspicious Account Joined')
          .setDescription(`User: ${member} (${member.user.tag})`)
          .addFields(
            { name: 'Account Age', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` },
            { name: 'Email Verified', value: member.user.verified ? 'Yes' : 'No' }
          )
          .setColor('Orange')
          .setTimestamp();
        client.channels.cache.get(MOD_LOG_CHANNEL_ID)?.send({ embeds: [embed] });
      }
    });
  }
};

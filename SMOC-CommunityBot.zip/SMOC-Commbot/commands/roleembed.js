const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  PermissionsBitField
} = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

module.exports = {
  data: new SlashCommandBuilder()
    .setName('createembed')
    .setDescription('Create a role selection embed.')
    .addStringOption(option =>
      option.setName('title')
        .setDescription('Title of the embed')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role1')
        .setDescription('Role option 1')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role2')
        .setDescription('Role option 2')
        .setRequired(false))
    .addRoleOption(option =>
      option.setName('role3')
        .setDescription('Role option 3')
        .setRequired(false))
    .addRoleOption(option =>
      option.setName('role4')
        .setDescription('Role option 4')
        .setRequired(false))
    .addRoleOption(option =>
      option.setName('role5')
        .setDescription('Role option 5')
        .setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const memberRoles = interaction.member.roles.cache;
    const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
    if (!userRoleId) {
      return interaction.editReply({ content: 'You do not have permission to use this command.' });
    }

    const title = interaction.options.getString('title');
    const roleOptions = [];

    for (let i = 1; i <= 5; i++) {
      const role = interaction.options.getRole(`role${i}`);
      if (role) {
        roleOptions.push(role);
      }
    }

    if (roleOptions.length === 0) {
      return interaction.editReply({ content: 'You must provide at least one role.' });
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription('Select a role from the dropdown below.')
      .setColor('#00AAFF')
      .setTimestamp();

    const menu = new StringSelectMenuBuilder()
      .setCustomId('role_selector')
      .setPlaceholder('Choose your role...')
      .addOptions(
        roleOptions.map(role =>
          new StringSelectMenuOptionBuilder()
            .setLabel(role.name)
            .setValue(role.id)
        )
      );

    const row = new ActionRowBuilder().addComponents(menu);

    await interaction.channel.send({ embeds: [embed], components: [row] });

    const logChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setColor('#ffaa00')
        .setTitle('Role Embed Created')
        .addFields(
          { name: 'Created by', value: `<@${interaction.user.id}> (${interaction.user.tag})` },
          { name: 'Channel', value: `<#${interaction.channel.id}>` },
          { name: 'Title', value: title },
          { name: 'Roles', value: roleOptions.map(r => `<@&${r.id}>`).join(', ') }
        )
        .setTimestamp();
      await logChannel.send({ embeds: [logEmbed] });
    }

    try {
      await interaction.user.send({
        content: `✅ Your role embed titled **"${title}"** was created in <#${interaction.channel.id}>.`,
        embeds: [embed]
      });
    } catch (err) {
      console.warn('Failed to DM user:', err.message);
    }

    await interaction.editReply({ content: 'Embed created successfully!' });
  }
};

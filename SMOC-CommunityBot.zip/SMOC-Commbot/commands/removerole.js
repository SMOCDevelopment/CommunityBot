const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removerole')
    .setDescription('Remove a role from a user by mention or ID.')
    .addStringOption(option =>
      option.setName('target')
        .setDescription('User mention or ID')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Role to remove')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for removing the role')
        .setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const targetInput = interaction.options.getString('target');
    const role = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const hasPermission = ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId));
    if (!hasPermission) {
      return interaction.editReply({ content: '❌ You do not have permission to use this command.' });
    }

    const idMatch = targetInput.match(/\d{17,19}/);
    if (!idMatch) {
      return interaction.editReply({ content: '❌ Invalid user mention or ID.' });
    }

    const targetId = idMatch[0];
    let targetMember;

    try {
      targetMember = await interaction.guild.members.fetch(targetId);
    } catch {
      return interaction.editReply({ content: '❌ Could not find that user in the server.' });
    }

    if (!targetMember.roles.cache.has(role.id)) {
      return interaction.editReply({
        content: `⚠️ **${targetMember.user.tag}** does not have the **${role.name}** role.`
      });
    }

    try {
      await targetMember.roles.remove(role, reason);
    } catch (error) {
      console.error('Role removal error:', error);
      return interaction.editReply({
        content: '❌ Failed to remove the role. Make sure I have the correct permissions.'
      });
    }

    const dmEmbed = new EmbedBuilder()
      .setColor('Red')
      .setTitle(`A role was removed in ${interaction.guild.name}`)
      .setDescription(`The **${role.name}** role was removed from you.`)
      .addFields(
        { name: 'Removed By', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason, inline: true }
      )
      .setTimestamp();

    try {
      await targetMember.send({ embeds: [dmEmbed] });
    } catch (dmError) {
      console.warn(`Could not DM ${targetMember.user.tag}:`, dmError.message);
    }

    const logChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setColor('#FF5555')
        .setTitle('🗑️ Role Removed')
        .addFields(
          { name: 'Target User', value: `<@${targetMember.id}> (${targetMember.user.tag})`, inline: false },
          { name: 'Role Removed', value: `${role.name}`, inline: true },
          { name: 'Removed By', value: `<@${interaction.user.id}> (${interaction.user.tag})`, inline: true },
          { name: 'Reason', value: reason, inline: false }
        )
        .setTimestamp();

      await logChannel.send({ embeds: [logEmbed] });
    }

    const successEmbed = new EmbedBuilder()
      .setColor('Orange')
      .setTitle('✅ Role Removed')
      .setDescription(`Successfully removed **${role.name}** from <@${targetMember.id}>.`)
      .addFields(
        { name: 'User', value: `${targetMember.user.tag} (${targetMember.id})`, inline: true },
        { name: 'Removed By', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
        { name: 'Reason', value: reason, inline: false }
      )
      .setTimestamp();

    return interaction.editReply({ embeds: [successEmbed] });
  }
};

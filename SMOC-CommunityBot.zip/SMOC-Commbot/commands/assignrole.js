const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');

const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('assignrole')
    .setDescription('Assign a role to a user by mention or ID.')
    .addStringOption(option =>
      option.setName('target')
        .setDescription('User mention or ID')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Role to assign')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for assigning the role')
        .setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const targetInput = interaction.options.getString('target');
    const role = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const hasPermission = ALLOWED_ROLES.some(roleId => interaction.member.roles.cache.has(roleId));
    if (!hasPermission) {
      return interaction.editReply({ content: '❌ You do not have permission to use this command.' });
    }

    const idMatch = targetInput.match(/\d{17,19}/);
    if (!idMatch) {
      return interaction.editReply({ content: '❌ Invalid user mention or ID.' });
    }

    const targetId = idMatch[0];
    let targetMember;

    try {
      targetMember = await interaction.guild.members.fetch(targetId);
    } catch {
      return interaction.editReply({ content: '❌ Could not find that user in the server.' });
    }

    if (targetMember.roles.cache.has(role.id)) {
      return interaction.editReply({
        content: `⚠️ **${targetMember.user.tag}** already has the **${role.name}** role.`
      });
    }

    try {
      await targetMember.roles.add(role, reason);
    } catch (error) {
      console.error('Role assignment error:', error);
      return interaction.editReply({
        content: '❌ Failed to assign the role. Make sure I have the correct permissions.'
      });
    }

    const dmEmbed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`You were assigned a role in ${interaction.guild.name}`)
      .setDescription(`You were given the **${role.name}** role.`)
      .addFields(
        { name: 'Assigned By', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason, inline: true }
      )
      .setTimestamp();

    try {
      await targetMember.send({ embeds: [dmEmbed] });
    } catch (dmError) {
      console.warn(`Could not DM ${targetMember.user.tag}:`, dmError.message);
    }

    const logChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
    if (logChannel) {
      const logEmbed = new EmbedBuilder()
        .setColor('#0099FF')
        .setTitle('📋 Role Assigned')
        .addFields(
          { name: 'Target User', value: `<@${targetMember.id}> (${targetMember.user.tag})`, inline: false },
          { name: 'Role Assigned', value: `${role.name}`, inline: true },
          { name: 'Assigned By', value: `<@${interaction.user.id}> (${interaction.user.tag})`, inline: true },
          { name: 'Reason', value: reason, inline: false }
        )
        .setTimestamp();

      await logChannel.send({ embeds: [logEmbed] });
    }

    const successEmbed = new EmbedBuilder()
      .setColor('Green')
      .setTitle('✅ Role Assigned')
      .setDescription(`Successfully assigned **${role.name}** to <@${targetMember.id}>.`)
      .addFields(
        { name: 'User', value: `${targetMember.user.tag} (${targetMember.id})`, inline: true },
        { name: 'Assigned By', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
        { name: 'Reason', value: reason, inline: false }
      )
      .setTimestamp();

    return interaction.editReply({ embeds: [successEmbed] });
  }
};

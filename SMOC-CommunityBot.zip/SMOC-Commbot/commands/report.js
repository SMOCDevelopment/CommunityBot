const crypto = require('crypto'); 


 const reportChannelId = 'REPORT_CHANNEL'; // Your report channel CHNAGE THIS PLEASE

const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    AttachmentBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle 
} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('report')
        .setDescription('Report a user for a specific reason.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to report')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('reason')
                .setDescription('The reason for the report')
                .setRequired(true)
                .addChoices(
                    { name: 'Breaking Server Rules', value: 1 },
                    { name: 'Hacked Account', value: 2 },
                    { name: 'Sending Fishy Links', value: 3 },
                    { name: 'Account needs to be reviewed for security reasons', value: 4 },
                    { name: 'Leaking Assets / Using Leaked Assets', value: 5 }
                ))
        .addStringOption(option =>
            option.setName('proof')
                .setDescription('Optional: link to image/video proof (URL)'))
        .addAttachmentOption(option =>
            option.setName('file')
                .setDescription('Optional: attach image or video proof')),

    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getInteger('reason');
        const proofLink = interaction.options.getString('proof');
        const file = interaction.options.getAttachment('file');

        const reportChannel = interaction.guild.channels.cache.get(reportChannelId);

        if (!reportChannel) {
            return interaction.reply({ content: 'Report channel not found.', ephemeral: true });
        }

        const reasonText = {
            1: 'Breaking Server Rules',
            2: 'Hacked Account',
            3: 'Sending Fishy Links',
            4: 'Account needs to be reviewed for security reasons',
            5: 'Leaking Assets / Using Leaked Assets'
        }[reason];

        if (proofLink && !proofLink.match(/\.(jpeg|jpg|png|gif|mp4|mov|webm)$/i)) {
            return interaction.reply({ content: 'Proof URL must be an image or video link.', ephemeral: true });
        }

        if (file && !(file.contentType?.startsWith('image/') || file.contentType?.startsWith('video/'))) {
            return interaction.reply({ content: 'Attached file must be an image or video.', ephemeral: true });
        }

        const caseId = crypto.randomBytes(4).toString('hex').toUpperCase();

        const reportEmbed = {
            color: 0xff0000,
            title: 'New Report',
            fields: [
                { name: 'Reported User', value: `${user.tag} (${user.id})`, inline: true },
                { name: 'Reason', value: reasonText, inline: true },
                { name: 'Proof / Details', value: proofLink || 'No link provided.' },
                { name: 'Case ID', value: caseId, inline: true }
            ],
            footer: { text: `Reported by ${interaction.user.tag}` },
            timestamp: new Date()
        };

        const closeButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_report')
                .setLabel('Close Report')
                .setStyle(ButtonStyle.Danger)
        );

        const sentMessage = await reportChannel.send({
            embeds: [reportEmbed],
            files: file ? [file.url] : [],
            components: [closeButton]
        });

        await sentMessage.startThread({
            name: `Report: ${user.tag}`,
            autoArchiveDuration: 1440,
            reason: 'Discussion for the report'
        });

        await interaction.reply({ content: 'Your report has been submitted.', ephemeral: true });

        const collector = sentMessage.createMessageComponentCollector({ 
            filter: i => i.customId === 'close_report', 
            time: 8649700000 
        });

        collector.on('collect', async (btnInteraction) => {
            if (!btnInteraction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
                return btnInteraction.reply({ content: 'You do not have permission to close this report.', ephemeral: true });
            }

            await btnInteraction.update({ content: 'This report has been marked as resolved.', embeds: [], components: [] });

         
            try {
                const resolvedEmbed = {
                    color: 0x00ff00,
                    title: 'Report Resolved',
                    description: `Thanks for keeping the community safe! Your case ID was: **${caseId}**.`,
                    timestamp: new Date()
                };
                await interaction.user.send({ embeds: [resolvedEmbed] });
            } catch (err) {
                console.error('Could not send DM to user:', err);
            }
        });

        collector.on('end', () => {
            sentMessage.edit({ components: [] }).catch(console.error);
        });
    }
};

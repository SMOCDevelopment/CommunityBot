const { SlashCommandBuilder, EmbedBuilder, ThreadAutoArchiveDuration, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');

const APPEAL_LINK = 'https://discord.gg/znXXf32n'; // Replace with your real appeal URL

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;
// =============================

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user by mention or ID')
    .addStringOption(option =>
      option.setName('target')
        .setDescription('User mention or ID')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for ban')
        .setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const targetInput = interaction.options.getString('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const memberRoles = interaction.member.roles.cache;
    const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
    if (!userRoleId) {
      return interaction.editReply({ content: 'You do not have permission to use this command.' });
    }

    const roleNamesMap = {
      [config.roles.admin]: 'Admin',
      [config.roles.moderator]: 'Moderator',
      [config.roles.manager]: 'Manager',
    };
    const userRoleName = roleNamesMap[userRoleId] || 'Staff';

    const idMatch = targetInput.match(/\d{17,19}/);
    if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
    const targetId = idMatch[0];

    try {
      let targetMember = null;
      try {
        targetMember = await interaction.guild.members.fetch(targetId);
      } catch {
      }

      if (targetMember && !targetMember.bannable) {
        return interaction.editReply({ content: 'I cannot ban this user.' });
      }

      const user = targetMember ? targetMember.user : await interaction.client.users.fetch(targetId);

      const dmEmbed = new EmbedBuilder()
        .setTitle(`You have been banned from ${interaction.guild.name}`)
        .setColor(0xff0000)
        .addFields(
          { name: 'Reason', value: reason },
          { name: 'Banned by', value: `${interaction.user.tag} (${userRoleName})` },
          { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` }
        )
        .setTimestamp()
        .setFooter({ text: 'If you believe this was a mistake, you can appeal your ban below.' });

      const appealButton = new ButtonBuilder()
        .setLabel('Appeal Ban')
        .setStyle(ButtonStyle.Link)
        .setURL(APPEAL_LINK);

      const row = new ActionRowBuilder().addComponents(appealButton);

      try {
        await user.send({ embeds: [dmEmbed], components: [row] });
      } catch (dmError) {
        console.warn(`Could not send DM to ${user.tag}`);
      }

      await new Promise(resolve => setTimeout(resolve, 1000));

      await interaction.guild.bans.create(targetId, { reason });

      const embed = new EmbedBuilder()
        .setTitle('User Banned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})` },
          { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
          { name: 'Reason', value: reason },
          { name: 'Banned by', value: `${interaction.user.tag}` },
          { name: 'Rank Of Staff', value: userRoleName }
        )
        .setColor(0xff0000)
        .setTimestamp();

      await interaction.editReply({ content: 'User has been banned.', embeds: [embed] });

      const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
      if (modLogChannel) {
        const logMessage = await modLogChannel.send({ embeds: [embed] });

        const thread = await logMessage.startThread({
          name: `Ban Review - ${user.tag}`,
          autoArchiveDuration: ThreadAutoArchiveDuration.OneWeek,
          reason: `Ban review thread for ${user.tag}`,
        });

        thread.send({
          content: `${interaction.user} (${userRoleName}) banned this user. Please provide valid proof of the ban here for owner/admin review.`,
        }).catch(console.error);
      }

    } catch (error) {
      console.error('Ban Error:', error);
      return interaction.editReply({ content: 'Failed to ban the user.' });
    }
  }
};

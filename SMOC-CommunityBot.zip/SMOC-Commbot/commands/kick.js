const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user by mention or ID')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for kick')
                .setRequired(false)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetInput = interaction.options.getString('target');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        const roleNamesMap = {
            [config.roles.admin]: 'Admin',
            [config.roles.moderator]: 'Moderator',
            [config.roles.manager]: 'Manager',
        };
        const userRoleName = roleNamesMap[userRoleId] || 'Staff';

        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        try {
            let targetMember = null;
            try {
                targetMember = await interaction.guild.members.fetch(targetId);
            } catch {
                return interaction.editReply({ content: 'Could not find that user in the guild.' });
            }

            if (!targetMember.kickable) {
                return interaction.editReply({ content: 'I cannot kick this user.' });
            }

            const dmEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`You have been kicked from ${interaction.guild.name}`)
                .setDescription(`You were kicked by **${interaction.user.tag}** (${userRoleName}).\n\n**Reason:** ${reason}`)
                .setTimestamp()
                .setFooter({ text: 'If you believe this was a mistake, please contact the server manager.' });

            try {
                await targetMember.send({ embeds: [dmEmbed] });
            } catch (dmError) {
                console.warn(`Could not send DM to ${targetMember.user.tag}`);
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); 

            await targetMember.kick(reason);

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('User Kicked')
                    .setDescription(`**User:** <@${targetId}> (${targetId})\n**Kicked by:** <@${interaction.user.id}> (${interaction.user.id})\n**Role:** ${userRoleName}\n**Reason:** ${reason}`)
                    .setTimestamp()
                    .setFooter({ text: `Actioned by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });
                await modLogChannel.send({ embeds: [embed] });
            }

            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('Kick Successful')
                .setDescription(`Successfully kicked <@${targetId}> (${targetId}) from the server.`)
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });
        } catch (error) {
            console.error('Kick command error:', error);
            await interaction.editReply({ content: 'An error occurred while trying to kick the user.' });
        }
    }
};

const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MUTED_ROLE_ID = config.roles.mute;
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;
// =============================

function durationToMs(duration) {
  switch(duration) {
    case '5m': return 5 * 60 * 1000;
    case '10m': return 10 * 60 * 1000;
    case '25m': return 25 * 60 * 1000;
    case '45m': return 45 * 60 * 1000;
    case '1h': return 60 * 60 * 1000;
    case '4h': return 4 * 60 * 60 * 1000;
    case '2d': return 2 * 24 * 60 * 60 * 1000;
    default: return 0;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute a user by mention or ID for a set duration')
    .addStringOption(option =>
      option.setName('target')
        .setDescription('User mention or ID')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('duration')
        .setDescription('Mute duration')
        .setRequired(true)
        .addChoices(
          { name: '5 minutes', value: '5m' },
          { name: '10 minutes', value: '10m' },
          { name: '25 minutes', value: '25m' },
          { name: '45 minutes', value: '45m' },
          { name: '1 Hour', value: '1h' },
          { name: '4 Hours', value: '4h' },
          { name: '2 Days', value: '2d' }
        ))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for mute')
        .setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const targetInput = interaction.options.getString('target');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const memberRoles = interaction.member.roles.cache;
    const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
    if (!userRoleId) {
      return interaction.editReply({ content: 'You do not have permission to use this command.' });
    }

    const idMatch = targetInput.match(/\d{17,19}/);
    if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
    const targetId = idMatch[0];

    const muteDurationMs = durationToMs(durationStr);
    if (muteDurationMs <= 0) return interaction.editReply({ content: 'Invalid duration selected.' });

    try {
      let targetMember = null;
      try {
        targetMember = await interaction.guild.members.fetch(targetId);
      } catch {
        return interaction.editReply({ content: 'User not found in this guild.' });
      }

      if (!targetMember.manageable) {
        return interaction.editReply({ content: 'I cannot mute this user.' });
      }

      const dmEmbed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle(`You have been muted in ${interaction.guild.name}`)
        .addFields(
          { name: 'Duration', value: durationStr, inline: true },
          { name: 'Reason', value: reason, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();

      try {
        await targetMember.send({ embeds: [dmEmbed] });
      } catch (dmError) {
        console.warn(`Could not send DM to ${targetMember.user.tag}`);
      }

      await new Promise(resolve => setTimeout(resolve, 1000));

      await targetMember.roles.add(MUTED_ROLE_ID, reason);

      const embed = new EmbedBuilder()
        .setColor('#ff0000')
        .setTitle('User Muted')
        .setDescription(
          `**User:** <@${targetId}>\n` +
          `**Duration:** ${durationStr}\n` +
          `**Reason:** ${reason}\n` +
          `**Moderator:** <@${interaction.user.id}>`
        )
        .setTimestamp();

      const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
      if (modLogChannel) {
        await modLogChannel.send({ embeds: [embed] });
      }

      await interaction.editReply({ content: `Successfully muted <@${targetId}> for ${durationStr}.` });

      setTimeout(async () => {
        try {
          const member = await interaction.guild.members.fetch(targetId);
          if (member && member.roles.cache.has(MUTED_ROLE_ID)) {
            await member.roles.remove(MUTED_ROLE_ID, 'Mute duration expired');
            if (modLogChannel) {
              const unmuteEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('User Unmuted')
                .setDescription(`**User:** <@${targetId}>\n**Reason:** Mute duration expired`)
                .setTimestamp();
              await modLogChannel.send({ embeds: [unmuteEmbed] });
            }
          }
        } catch (err) {
          console.error('Failed to unmute user:', err);
        }
      }, muteDurationMs);

    } catch (error) {
      console.error(error);
      await interaction.editReply({ content: 'An error occurred while trying to mute the user.' });
    }
  }
};

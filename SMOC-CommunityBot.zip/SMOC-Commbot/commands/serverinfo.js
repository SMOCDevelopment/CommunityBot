const { EmbedBuilder, SlashCommandBuilder, ChannelType } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Display detailed server information, including roles, channels, and bans.'),

  async execute(interaction) {
    await interaction.deferReply(); 

    const guild = interaction.guild;

    const owner = await guild.fetchOwner();
    const bans = await guild.bans.fetch().catch(() => null);
    const banCount = bans ? bans.size : 'No permission';
    const channels = guild.channels.cache;
    const roles = guild.roles.cache;

   
    const infoEmbed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle(`${guild.name} — Server Information`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: '🧑‍💼 Owner', value: `${owner.user.tag} (<@${owner.id}>)`, inline: true },
        { name: '📅 Created On', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
        { name: '👥 Members', value: `${guild.memberCount}`, inline: true },
        { name: '📄 Channels', value: `${channels.size}`, inline: true },
        { name: '🏷️ Roles', value: `${roles.size}`, inline: true },
        { name: '⛔ Bans', value: `${banCount}`, inline: true }
      )
      .setFooter({ text: `Server ID: ${guild.id}` })
      .setTimestamp();


    const roleList = roles
      .filter(r => r.id !== guild.id) 
      .sort((a, b) => b.position - a.position)
      .map(r => `<@&${r.id}>`);

    const roleEmbeds = [];
    let roleChunk = '';

    for (const role of roleList) {
      if ((roleChunk + role + ', ').length > 1024) {
        roleEmbeds.push(
          new EmbedBuilder()
            .setColor('#6666ff')
            .setTitle('📋 Server Roles')
            .setDescription(roleChunk.slice(0, -2))
            .setTimestamp()
        );
        roleChunk = '';
      }
      roleChunk += `${role}, `;
    }
    if (roleChunk.length) {
      roleEmbeds.push(
        new EmbedBuilder()
          .setColor('#6666ff')
          .setTitle('📋 Server Roles')
          .setDescription(roleChunk.slice(0, -2))
          .setTimestamp()
      );
    }


    const channelList = channels
      .filter(c => c.type !== ChannelType.GuildCategory)
      .sort((a, b) => a.rawPosition - b.rawPosition)
      .map(c => `<#${c.id}>`);

    const channelEmbeds = [];
    let channelChunk = '';

    for (const channel of channelList) {
      if ((channelChunk + channel + ', ').length > 1024) {
        channelEmbeds.push(
          new EmbedBuilder()
            .setColor('#4444aa')
            .setTitle('📁 Server Channels')
            .setDescription(channelChunk.slice(0, -2))
            .setTimestamp()
        );
        channelChunk = '';
      }
      channelChunk += `${channel}, `;
    }
    if (channelChunk.length) {
      channelEmbeds.push(
        new EmbedBuilder()
          .setColor('#4444aa')
          .setTitle('📁 Server Channels')
          .setDescription(channelChunk.slice(0, -2))
          .setTimestamp()
      );
    }

  
    await interaction.editReply({
      content: `📊 Server info for **${guild.name}**:`,
      embeds: [infoEmbed, ...roleEmbeds, ...channelEmbeds],
    });
  }
};

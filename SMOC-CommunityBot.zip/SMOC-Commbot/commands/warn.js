const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');


// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================


module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Warn a user by mention or ID')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for warning')
                .setRequired(false)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetInput = interaction.options.getString('target');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        try {
            let targetMember = null;
            try {
                targetMember = await interaction.guild.members.fetch(targetId);
            } catch {
                return interaction.editReply({ content: 'Could not find that user in the guild.' });
            }

            const dmEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`You have been warned in ${interaction.guild.name}`)
                .setDescription(`You were warned by **${interaction.user.tag}**.\n\n**Reason:** ${reason}`);

            try {
                await targetMember.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.error('Failed to send DM:', error);
            }

            const logEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('User Warned')
                .setDescription(`<@${targetMember.id}> was warned by <@${interaction.user.id}> Rank: <@&${userRoleId}>.\n\n**Reason:** ${reason}`)
                .setTimestamp();

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                await modLogChannel.send({ embeds: [logEmbed] });
            } else {
                console.error('Mod log channel not found:', MOD_LOG_CHANNEL_ID);
            }   
            
            return interaction.editReply({ content: `✅ **${targetMember.user.tag}** has been warned.` });
        }
        catch (error) {
            console.error('Error executing warn command:', error);
            return interaction.editReply({ content: '❌ An error occurred while trying to warn the user.' });
        }
    }
};
const { SlashCommandBuilder, EmbedBuilder, ThreadAutoArchiveDuration, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log;
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a user by mention or ID')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for unban')
                .setRequired(false)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetInput = interaction.options.getString('target');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        try {
            await interaction.guild.members.unban(targetId, reason);

            const logEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('User Unbanned')
                .setDescription(`**<@${targetId}>** has been unbanned by <@${interaction.user.id}>.\n\n**Reason:** ${reason}`)
                .setTimestamp();

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                await modLogChannel.send({ embeds: [logEmbed] });
            }

            return interaction.editReply({ content: `Successfully unbanned <@${targetId}>.` });
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: 'An error occurred while trying to unban the user.' });
        }
    }
};
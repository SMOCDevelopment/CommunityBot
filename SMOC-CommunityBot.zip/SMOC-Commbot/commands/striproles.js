const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');


// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
const MEMBER_ROLE_ID = config.roles.member;
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('striproles')
        .setDescription('Strip all roles from a user and give them the member role')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetInput = interaction.options.getString('target');
        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        let targetMember;
        try {
            targetMember = await interaction.guild.members.fetch(targetId);
        } catch {
            return interaction.editReply({ content: 'Could not find that user in the guild.' });
        }

        const rolesToRemove = targetMember.roles.cache.filter(role => role.id !== MEMBER_ROLE_ID && !role.managed);
        
        if (rolesToRemove.size === 0) {
            return interaction.editReply({ content: 'This user has no roles to strip.' });
        }

        try {
            await targetMember.roles.remove(rolesToRemove);
            await targetMember.roles.add(MEMBER_ROLE_ID);

            const logEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Roles Stripped')
                .setDescription(`**${targetMember.user.tag}**'s roles were stripped by <@${interaction.user.id}>.`)
                .addFields(
                    { name: 'Stripped Roles', value: rolesToRemove.map(role => role.name).join(', ') || 'None' },
                    { name: 'New Role', value: `<@&${MEMBER_ROLE_ID}>` }
                )
                .setTimestamp();

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                await modLogChannel.send({ embeds: [logEmbed] });
            }   
            return interaction.editReply({ content: `Successfully stripped roles from **${targetMember.user.tag}** and assigned the member role.` });
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: 'An error occurred while trying to strip roles.' });
        }                  
    }
};
            



const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');



// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

 
module.exports = {
    data: new SlashCommandBuilder()
        .setName('dmuser')
        .setDescription('DM a user by mention or ID')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Message to send to the user')
                .setRequired(true)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetInput = interaction.options.getString('target');
        const message = interaction.options.getString('message');

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        try {
            let targetMember = null;
            try {
                targetMember = await interaction.guild.members.fetch(targetId);
            } catch {
                return interaction.editReply({ content: 'Could not find that user in the guild.' });
            }

            const dmEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle(`Message from ${interaction.guild.name}`)
                .setDescription(message);

            try {
                await targetMember.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.error('Failed to send DM:', error);
                return interaction.editReply({ content: 'Failed to send DM to the user.' });
            }

            const logEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('User DMed')
                .setDescription(`**${interaction.user.tag}** (${userRoleId}) sent a DM to **${targetMember.user.tag}**.\n\n**Message:** ${message}`)
                .setTimestamp();

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                await modLogChannel.send({ embeds: [logEmbed] });
            }

            return interaction.editReply({ content: `Successfully sent a DM to **${targetMember.user.tag}**.` });
        }
        catch (error) {
            console.error('Error executing dmuser command:', error);
            return interaction.editReply({ content: 'An error occurred while trying to DM the user.' });
        }
    }
};
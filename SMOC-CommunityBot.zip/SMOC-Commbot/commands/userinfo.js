const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');


// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Get information about a user by mention or ID')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('User mention or ID')
                .setRequired(true))
        .addBooleanOption(option =>
            option.setName('ephemeral')
                .setDescription('Whether to send the response as ephemeral (only visible to you)')
                .setRequired(false)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: interaction.options.getBoolean('ephemeral') || false });

        const targetInput = interaction.options.getString('target');
        const idMatch = targetInput.match(/\d{17,19}/);
        if (!idMatch) return interaction.editReply({ content: 'Invalid user mention or ID.' });
        const targetId = idMatch[0];

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        let targetMember;
        try {
            targetMember = await interaction.guild.members.fetch(targetId);
        } catch {
            return interaction.editReply({ content: 'Could not find that user in the guild.' });
        }

        const userInfoEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`User Information for ${targetMember.user.tag}`)
            .addFields(
                { name: 'ID', value: targetMember.id, inline: true },
                { name: 'Joined Server', value: new Date(targetMember.joinedTimestamp).toLocaleDateString(), inline: true },
                { name: 'Account Created', value: new Date(targetMember.user.createdTimestamp).toLocaleDateString(), inline: true },
                { name: 'Roles', value: targetMember.roles.cache.map(role => role.name).join(', ') || 'No roles' }
            )
            .setThumbnail(targetMember.user.displayAvatarURL())
            .setTimestamp();

        return interaction.editReply({ embeds: [userInfoEmbed] });
    }
};
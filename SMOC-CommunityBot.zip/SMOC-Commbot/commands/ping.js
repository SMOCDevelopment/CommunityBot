const { EmbedBuilder, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Replies with Pong!'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('Pong!')
            .setDescription(`IM ALIVE AND RUNNING! -- Latency is ${Date.now() - interaction.createdTimestamp}ms.`);

        const button = new ButtonBuilder()
            .setLabel('Commands not working? Join SMOC Discord Server')
            .setURL('https://discord.gg/6r3j3dydUr')
            .setStyle(ButtonStyle.Link);

        const row = new ActionRowBuilder().addComponents(button);

        await interaction.reply({ embeds: [embed], components: [row] });

        console.log(`Ping command executed by ${interaction.user.tag}`);
    }
};

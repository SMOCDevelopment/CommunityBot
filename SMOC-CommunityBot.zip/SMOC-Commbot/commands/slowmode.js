const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');


// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slowmode')
        .setDescription('Set slow mode for the channel')
        .addSubcommand(subcommand =>
            subcommand.setName('set')
                .setDescription('Set slow mode duration')
                .addIntegerOption(option =>
                    option.setName('duration')
                        .setDescription('Duration in seconds (0 to disable)')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand.setName('off')
                .setDescription('Turn off slow mode')),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        if (interaction.options.getSubcommand() === 'set') {
            const duration = interaction.options.getInteger('duration');
            if (duration < 0 || duration > 21600) { // 6 hours max
                return interaction.editReply({ content: 'Please specify a valid duration between 0 and 21600 seconds.' });
            }

            try {
                await interaction.channel.setRateLimitPerUser(duration);
                const logEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Slow Mode Set')
                    .setDescription(`**${interaction.user.tag}** set slow mode to **${duration}** seconds.`)
                    .setTimestamp();

                const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
                if (modLogChannel) {
                    await modLogChannel.send({ embeds: [logEmbed] });
                }

                return interaction.editReply({ content: `Slow mode set to **${duration}** seconds.` });
            } catch (error) {
                console.error(error);
                return interaction.editReply({ content: 'An error occurred while trying to set slow mode.' });
            }
        } else if (interaction.options.getSubcommand() === 'off') {
            try {
                await interaction.channel.setRateLimitPerUser(0);
                const logEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Slow Mode Disabled')
                    .setDescription(`**${interaction.user.tag}** disabled slow mode.`)
                    .setTimestamp();
                const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
                if (modLogChannel) {
                    await modLogChannel.send({ embeds: [logEmbed] });
                }
                return interaction.editReply({ content: 'Slow mode has been disabled.' });
            }
            catch (error) {
                console.error(error);
                return interaction.editReply({ content: 'An error occurred while trying to disable slow mode.' });
            }

        }
    }
};

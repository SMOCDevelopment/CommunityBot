const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');

// === Modify these as needed ===
const ALLOWED_ROLES = [config.roles.admin, config.roles.moderator, config.roles.manager];
const MOD_LOG_CHANNEL_ID = config.logs.mod_log
// =============================

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Purge messages from a channel')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of messages to purge (1-100)')
                .setRequired(true)),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const amount = interaction.options.getInteger('amount');
        if (amount < 1 || amount > 100) {
            return interaction.editReply({ content: 'Please specify a number between 1 and 100.' });
        }

        const memberRoles = interaction.member.roles.cache;
        const userRoleId = ALLOWED_ROLES.find(roleId => memberRoles.has(roleId));
        if (!userRoleId) {
            return interaction.editReply({ content: 'You do not have permission to use this command.' });
        }

        try {
            const deletedMessages = await interaction.channel.bulkDelete(amount, true);
            const logEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Messages Purged')
                .setDescription(`**${deletedMessages.size}** messages were purged by <@${interaction.user.id}>.`)
                .setTimestamp();

            const modLogChannel = interaction.guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
            if (modLogChannel) {
                await modLogChannel.send({ embeds: [logEmbed] });
            }

            return interaction.editReply({ content: `Successfully purged **${deletedMessages.size}** messages.` });
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: 'An error occurred while trying to purge messages.' });
        }
    }
};
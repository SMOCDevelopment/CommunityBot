module.exports = {
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
    guildId: process.env.GUILD_ID,

    channels: {
        welcome_channel: 'CHANNEL_ID_WELCOME',
    },

    logs: {
        channel_log: 'CHANNEL_ID_LOGS',
        error_log: 'CHANNEL_ID_ERROR_LOGS',
        mod_log: 'CHANNEL_ID_MOD_LOGS',
    },

    roles: {
        member: 'MEMBER_ROLE',
        mute: 'MUTE_ROLE',
        linkBypass: 'LINK_BY_PASS',
        admin: 'ADMIN_ROLE',
        moderator: 'MOD_ROLE',
        manager: 'MANAGER_ROLE',
    }
};

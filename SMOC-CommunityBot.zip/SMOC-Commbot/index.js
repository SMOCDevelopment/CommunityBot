require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
const config = require('./config');
const { Console } = require('console');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates
    ]
});

client.commands = new Collection();
client.events = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commands = [];
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        if (command.data && command.execute) {
            client.commands.set(command.data.name, command);
            commands.push(command.data.toJSON());
        }
    }
}

const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const event = require(path.join(eventsPath, file));
        if (event.name && event.execute) {
            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args, client));
            } else {
                client.on(event.name, (...args) => event.execute(...args, client));
            }
            client.events.set(event.name, event);
        }
    }
}

async function registerCommands() {
    const rest = new REST({ version: '10' }).setToken(config.token);

    try {
        console.log('Started refreshing application (/) commands.');

        if (config.guildId) {
            await rest.put(
                Routes.applicationGuildCommands(config.clientId, config.guildId),
                { body: commands },
            );
            console.log('Successfully reloaded application (/) commands for guild.');
        } else {
            await rest.put(
                Routes.applicationCommands(config.clientId),
                { body: commands },
            );
            console.log('Successfully reloaded application (/) commands globally.');
        }
    } catch (error) {
        console.error(error);
    }
}

registerCommands().then(() => {
    client.login(config.token);
});

function isValidId(value) {
    return typeof value === 'string' && /^\d+$/.test(value);
}

// Basic debug logs
console.log('Token:', config.token ? 'Loaded' : 'Missing!');
console.log('Client ID:', isValidId(config.clientId) ? 'Loaded' : 'Missing!');
console.log('Guild ID:', isValidId(config.guildId) ? 'Loaded' : 'Missing!');
console.log('Commands Loaded:', client.commands.size);
console.log('Events Loaded:', client.events.size);
console.log('Admin Role ID:', isValidId(config.roles.admin) ? 'Loaded' : 'Missing!');
console.log('Moderator Role ID:', isValidId(config.roles.mod) ? 'Loaded' : 'Missing!');
console.log('Mute Role ID:', isValidId(config.roles.mute) ? 'Loaded' : 'Missing!');
console.log('Manager Role ID:', isValidId(config.roles.manager) ? 'Loaded' : 'Missing!');

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});
